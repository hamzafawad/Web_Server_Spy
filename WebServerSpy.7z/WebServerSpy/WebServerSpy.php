<?php
// Sample data


while (true)
{   echo "\n\t\t\t\t\t\tWeb_Server_Spy \tV:1.0";
	echo "\n";
	$data = array(
	array("0","Disclaimer", "Disclaimer about Web_Server_Spy Tool..."),
    array("1","SSV", "Server software and version."),
    array("2","OSV", "Operating system and version."),
    array("3","PortsSc", "Information about Ports_Scanning open/close."),
    array("4","WIR", "Website-information-retrieval:such as the web server_name,IP_address,Port,protocol,responsetime..."),
    array("5","CMS", "CMS manages content, web server serves content. CMS often needs a web server to host its content..."),
    array("6","Raw Data", "To retrieve all data from web server A-Z information such as text, images, audio, and numerical data."),
    array("7","Subdomains", "To find all Subdomains with ipies address,servers names, also status_code."),
    array("8","Serverinfo", "To find all info about web_server like Server timezone,geolocation... "),
    array("9","Emails", "To find all Emails of web_server also hidden emails can find. "),
    array("10","Links", "To extract all types of links like, jpg|jpeg|gif|png|js... "),
    array("11","S_TimeInfo","To show Every Information about server time."),
    array("12","S_Owr_Info","To show Every Information about server Ower Information."),
    array("13","Geolcation","To show all Information about server location like,Latitude,Longitude."),
    array("14","Response ","To check all of response like http,methods,status_code..."),
    array("15","S_S_lang ","To check all of server side language,java,python,php,JS..."),
    array("16","S_Rt_Dir ","To find  all files/subdir of server like /wp-admin,/download..."),
    array("17","SSL_Cer ","To  check Web server SSL certificate information."),
    array("18","DNS_Info ","To check all web server information like,AAAA,MX,SPF..."),
    array("19","FingerPr ", "Fingerprinting is a method of identifying individuals by analyzing unique patterns on their fingers..."),
    array("20","Firwll/Pro","Firewall To checking Firewall/proxy of web server info..."),
    array("21","Help","help about tool useage..."),
    array("22","About_Tool","Read more about our tool..."),
    array("23","Exit","Terminate tool.")

    
);



// Create the table header
$table_header = "| " . str_pad("SN", 2) . " | " . str_pad("Short Form", 9) . " | " . str_pad("Description", 12) . " |\n";
$table_header .= "+----+------------+--------------+\n";

// Create the table body
$table_body = "";
foreach ($data as $row) {
    $table_body .= "| " . str_pad($row[0], 2) . " | " . str_pad($row[1], 10) . " | " . str_pad($row[2], 7) . "\n";
}

// Print the table
echo $table_header . $table_body;
echo "\n";
date_default_timezone_set("Asia/Karachi");

$current_time = date("h:i:s A");
$current_date = date("m/d/Y");

echo "[" . $current_time . "|" . $current_date."]";
echo "\n\n";
$choice=readline("Enter choice?: ");
echo "\n";

if($choice=="0")
{
	echo "Web ServerSpy is a tool that helps website owners and admins understand their website's performance and security, \t\nbut it's not perfect and shouldn't be the only source of information. Always consult a professional and follow \t\nbest practices for website security and maintenance.Note:this Tool use your own risk.";
    $anykey=readline("\nanykey press continue: ");
}

else if ($choice=="1") 
{
	
$url=readline("Put URL: ");	
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_NOBODY, true);
$response = curl_exec($ch);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$header = substr($response, 0, $headerSize);
curl_close($ch);

if (preg_match('/Server:\s*([^\r\n]*)/i', $header, $matches)) {
    $serverSoftware = $matches[1];
    echo "Server software and version: " . $serverSoftware . "\n";
}

if (preg_match('/X-Powered-By:\s*([^\r\n]*)/i', $header, $matches)) {
    $poweredBy = $matches[1];
    echo "Powered by: " . $poweredBy . "\n";
}

if (preg_match('/Server:\s*([^\r\n]*)/i', $header, $matches)) {
    $serverName = $matches[1];
    echo "Server name: " . $serverName . "\n";
}

if (preg_match('/Content-Type:\s*([^\r\n]*)/i', $header, $matches)) {
    $contentType = $matches[1];
    echo "Content type: " . $contentType . "\n";
}
$anykey=readline("\nanykey press continue: ");

}
else if ($choice=="2") 
{

$url=readline("Put URL: ");	

$headers = get_headers("https://".($url));

foreach ($headers as $header) {
    echo $header . "\n";
}
$anykey=readline("\nanykey press continue: ");

}
else if ($choice=="3")
{


$ports = array(
    20 => 'FTP - Data Transfer',
    21 => 'FTP - Command and Control',
    22 => 'SSH',
    23 => 'Telnet',
    25 => 'SMTP',
    53 => 'DNS',
    80 => 'HTTP',
    110 => 'POP3',
    119 => 'NNTP',
    123 => 'NTP',
    143 => 'IMAP',
    161 => 'SNMP',
    194 => 'IRC',
    443 => 'HTTPS',
    587 => 'SMTP Submission',
    993 => 'IMAP SSL',
    995 => 'POP3 SSL',
    1723 => 'PPTP',
    3306 => 'MySQL',
    3389 => 'Remote Desktop',
    5900 => 'VNC',
    8080 => 'HTTP Alternate'
);
$host=readline("Put URL: ");	
foreach ($ports as $port => $service) {
    $fp = @fsockopen($host, $port, $errno, $errstr, 5);
    if ($fp) {
        echo "Port $port ($service) is open.\n";
        fclose($fp);
    } else {
        echo "Port $port ($service) is closed or could not connect.\n";
    }
}
$anykey=readline("\nanykey press continue: ");

}


else if ($choice=="4") 
{
	
    $url = readline("Put URL: ");
    $ip_address = gethostbyname(parse_url("https://".($url), PHP_URL_HOST));
    $web_server_name = gethostbyaddr($ip_address);
    $port = getservbyname(parse_url("https://".($url), PHP_URL_SCHEME), 'tcp');
    $protocol = parse_url("https://".($url), PHP_URL_SCHEME);
    $response_time = microtime(true);
    $content = file_get_contents("https://".($url));
    $response_time = microtime(true) - $response_time;
    
    echo "Web server name: " . $web_server_name . "\n";
    echo "IP address: " . $ip_address . "\n";
    echo "Port: " . $port . "\n";
    echo "Protocol: " . $protocol . "\n";
    echo "Response time: " . $response_time . " seconds" . "\n";
    echo "Content length: " . strlen($content) . " bytes" . "\n";

    $anykey=readline("\nanykey press continue: ");

}

else if ($choice=="5") 
{
	

function get_cms_version($url) {
    // Initialize cURL
    $ch = curl_init();

    // Set the URL
    curl_setopt($ch, CURLOPT_URL, $url);

    // Set the user agent
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36');

    // Set the return transfer option to true
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the cURL request
    $html = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        echo 'Error: ' . curl_error($ch);
        return false;
    }

    // Close the cURL resource
    curl_close($ch);

    // Identify the CMS
    if (stripos($html, 'joomla') !== false) {
        // Extract the Joomla version number if it's found
        if (preg_match('/<meta name="generator" content="Joomla! (\d+\.\d+)/', $html, $matches)) {
            return 'Joomla ' . $matches[1];
        } else {
            return 'Joomla';
        }
    } elseif (stripos($html, 'drupal') !== false) {
        // Extract the Drupal version number if it's found
        if (preg_match('/<meta name="Generator" content="Drupal (\d+\.\d+)/', $html, $matches)) {
            return 'Drupal ' . $matches[1];
        } else {
            return 'Drupal';
        }
    } elseif (stripos($html, 'wordpress') !== false) {
        // Extract the WordPress version number if it's found
        if (preg_match('/<meta name="generator" content="WordPress (\d+\.\d+)/', $html, $matches)) {
            return 'WordPress ' . $matches[1];
        } else {
            return 'WordPress';
        }
    } elseif (stripos($html, 'modx') !== false) {
        // Extract the MODX version number if it's found
        if (preg_match('/<meta name="generator" content="MODX (\d+\.\d+)/', $html, $matches)) {
            return 'MODX ' . $matches[1];
        } else {
            return 'MODX';
        }
    } else {
        return 'Unknown';
    }
}

// The URL of the website to check
$url = readline("Put URL: ");

// The CMS names to check
$cms_names = array('blogger', 'concrete5', 'contao', 'craft', 'drupal', 'expressionengine', 'ghost', 'joomla', 'magento', 'opencart', 'prestashop', 'shopify', 'squarespace', 'typo3', 'umbraco', 'wix', 'wordpress');

// An array to store the results
$cms_versions = array();

// Loop through the CMS names and check each one
foreach ($cms_names as $cms_name) {
    $cms_url = 'https://' . $url . '/' . $cms_name;
    $cms = get_cms_version($cms_url);

    // Store the name of the CMS and its version in the $cms_versions array
    $cms_versions[$cms_url] = $cms;
}

// Print the results
foreach ($cms_versions as $cms_url => $cms) {
    echo 'The CMS of ' . $cms_url . ' is: ' . $cms . PHP_EOL;
}

$anykey=readline("\nanykey press continue: ");
}

else if ($choice=="6") 
{
 echo "\nRaw Data\n\n";
$url = readline("Put URL: ");

// Initialize curl
$ch = curl_init();

// Set curl options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_VERBOSE, true);

// Execute the curl request
$response = curl_exec($ch);

// Check for curl errors
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
}

curl_close($ch);
$anykey=readline("\nanykey press continue: ");

}

else if ($choice=="7") 
{

	function find_subdomains($domain) {
    $subdomains = array();
    $json = file_get_contents('https://crt.sh/?q=%25.' . $domain . '&output=json');
    $data = json_decode($json);
    foreach ($data as $row) {
        $name = $row->name_value;
        if (strpos($name, '*.') === 0) {
            $name = substr($name, 2);
        }
        $records = @dns_get_record($name, DNS_A);
        if ($records !== false && isset($records[0]['ip'])) {
            $ip = $records[0]['ip'];
            if (!in_array($name, $subdomains) && $ip != $name) {
                $subdomains[] = $name;
                $url = "http://$name";
                $status_code = get_http_response_code($url);
                echo $name . ' => ' . $ip . ' => ' . $status_code . "\n";
            }
        } else {
            echo "Error: DNS query failed for $name\n";
        }
    }
    return $subdomains;
}

function get_http_response_code($url) {
    try {
        $headers = get_headers($url);
        $status_code = substr($headers[0], 9, 3);
    } catch (Exception $e) {
        $status_code = 'N/A';
    }
    return $status_code;
}

$domain =readline("Put URL: ");
$subdomains = find_subdomains($domain);
if (!empty($subdomains)) {
    echo "Subdomains for " . $domain . ": \n";
    foreach ($subdomains as $subdomain) {
        echo $subdomain . "\n";
    }
} else 
{
    echo "No subdomains found for " . $domain . "\n";
}
$anykey=readline("\nanykey press continue: ");

}

else if ($choice=="8")
{
$domain = readline("Put URL: ");
$whois = shell_exec("whois $domain");
echo $whois;
$anykey=readline("\nanykey press continue: ");

}
else if ($choice=="9")
{
	$url = readline("Put Url: ");
$pattern = '/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/';

// List of email domains to check against
$email_domains = array('com', 'edu', 'org', 'gov', 'net', 'mil', 'info', 'biz', 'co', 'io', 'me', 'tv', 'pro', 'name', 'us');

// Load the HTML content of the webpage
$html = file_get_contents("https://".$url);

// Find all email addresses in the HTML content
preg_match_all($pattern, $html, $matches);

// Print the results
echo "Email addresses found on $url:\n";
$counter=1;
foreach ($matches[0] as $email) {
    $domain = explode('@', $email)[1];
    $domain_extension = explode('.', $domain)[1];
    if (in_array($domain_extension, $email_domains)) {
        echo $counter." ",$email . "\n";
        $counter+=1;
    }
}

echo "\nServer administrator email address\n";
$result = shell_exec("whois ".$url);

// Extract admin email address from the result
if(preg_match('/Admin Email:\s+(.*)/i', $result, $matches)) {
    $admin_email = $matches[1];
    echo "Admin email address for ".$url." is ".$admin_email."\n";
} else {
    echo "Could not find admin email address for ".$url;
}
echo "\n";
$anykey=readline("\nanykey press continue: ");

}



else if ($choice=="10")
{
	$url = readline("Put URL: ");

$ch = curl_init("https://".$url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);

if ($response === false) {
    echo "Error fetching URL: " . curl_error($ch);
    exit();
}

curl_close($ch);

$pattern = '/href=["\'\\/]([^"\'>]*\.[^"\']*)["\']/i';
if (preg_match_all($pattern, $response, $matches)) {
    $links = $matches[1];
    $links = array_unique($links);
    $links = array_filter($links, function($link) {
        return !preg_match('/\.(jpg|jpeg|gif|png|js|css|csv|docm|docx|html|php|mp3|mp4|ppt|pptx|rar|sldx|swf|txt|wav|zip|mov|flv|exe|php|js|css|html|py|cpp|net)$/i', $link);
    });

    foreach ($links as $index => $link) {
        echo "[$index] => $link" . PHP_EOL;
    }
} else 
{
    echo "No links found in response";
}
$anykey=readline("\nanykey press continue: ");

}

elseif ($choice=="") 
{
	echo "Empty...\n";
}

else if ($choice=="11")
{
$url=readline("Put URL: ");
date_default_timezone_set('Asia/Karachi');
$dst_enabled = (bool)date('I');

// Get server time
$server_time = date('Y-m-d h:i:s A');

// Get server response time
$start_time = microtime(true);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://".(($url))); // replace with your website URL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$output = curl_exec($ch);
$end_time = microtime(true);
curl_close($ch);
$server_response_time = round(($end_time - $start_time) * 1000, 3) . "ms";

// Get server processing time
$start_time = microtime(true);
// Insert your code for processing here
$end_time = microtime(true);
$server_processing_time = round(($end_time - $start_time) * 1000, 3) . "ms";

// Get server uptime
$uptime_seconds = floor(microtime(true) - $_SERVER["REQUEST_TIME_FLOAT"]);
$server_uptime = sprintf("%d days, %d hours, %d minutes, %d seconds", floor($uptime_seconds / 86400), floor(($uptime_seconds % 86400) / 3600), floor(($uptime_seconds % 3600) / 60), $uptime_seconds % 60);

// Output results
echo "Server time: $server_time\n";
echo "Server response time: $server_response_time\n";
echo "Server processing time: $server_processing_time\n";
echo "Server uptime: $server_uptime\n";
echo "Timezone: " . date_default_timezone_get() . "\n";
echo "Request time: " . date('Y-m-d h:i:s A', $_SERVER['REQUEST_TIME']) . "\n";
echo "Time stamps: " . time() . ", " . strtotime('now') . "\n";
echo "Date and time formats: " . date('Y-m-d h:i:s A') . ", " . date('F j, Y, g:i a') . "\n";
echo "Daylight saving time: " . ($dst_enabled ? "Enabled" : "Enabled") . "\n";

#some extra info about time.
echo "\n\n>>>>>>>>>>Some extra Information about server time<<<<<<<<<<\n\n";
$start_time = microtime(true);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);

$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$headers = substr($response, 0, $header_size);
$body = substr($response, $header_size);

$network_latency = round((microtime(true) - $start_time) * 1000, 2);

$ttfb_time = curl_getinfo($ch, CURLINFO_STARTTRANSFER_TIME) * 1000;
$dns_time = curl_getinfo($ch, CURLINFO_NAMELOOKUP_TIME) * 1000;
$connect_time = curl_getinfo($ch, CURLINFO_CONNECT_TIME) * 1000;
$ssl_time = curl_getinfo($ch, CURLINFO_APPCONNECT_TIME) * 1000;
$ttl_time = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
$tti_time = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
$page_load_time = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
$render_time = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
$ttfp_time = curl_getinfo($ch, CURLINFO_STARTTRANSFER_TIME) * 1000;
$ttfmp_time = curl_getinfo($ch, CURLINFO_STARTTRANSFER_TIME) * 1000;
$page_speed = curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000;
$page_weight = round(strlen($response) / 1024, 2);
$server_response_time = round(microtime(true) - $_SERVER["REQUEST_TIME_FLOAT"] * 1000);

// DOMContentLoaded event time
$dom_content_loaded_time = round($tti_time + $render_time);

// Time to fully loaded
$time_to_fully_loaded = round($page_load_time + $render_time);

// Time to visually complete
$time_to_visually_complete = round($ttfp_time + $render_time);

$time_to_interactive_complete = $tti_time;

// Time to First CPU Idle
$time_to_first_cpu_idle = $tti_time;

// Time to First Interactive
$time_to_first_interactive = $tti_time;

// Page Load Distribution
$page_load_distribution = "unknown";

// Average Page Load Time
$avg_page_load_time = $page_load_time;

// Average Server Connection Time
$avg_server_connection_time = $connect_time;

// Average Server Response Time
$avg_server_response_time = $server_response_time;

curl_close($ch);

echo "Network Latency: " . $network_latency . " ms\n";
echo "Time to first byte (TTFB): " . $ttfb_time . " ms\n";
echo "DNS lookup time: " . $dns_time . " ms\n";
echo "Connection time: " . $connect_time . " ms\n";
echo "SSL/TLS handshake time: " . $ssl_time . " ms\n";
echo "Time to last byte (TTLB): " . $ttl_time . " ms\n";
echo "Time to interactive (TTI): " . $tti_time . " ms\n";
echo "Page load time: " . $page_load_time . " ms\n";
echo "Render time: " . $render_time . " ms\n";
echo "Time to first paint (TTFP): " . $ttfp_time . " ms\n";
echo "Time to first meaningful paint (TTFMP): " . $ttfmp_time . " ms\n";
echo "Page speed: " . $page_speed . " ms\n";
echo "Page weight: " . $page_weight . " KB\n";
echo "Server response time: " . $server_response_time . " ms\n";
echo "DOMContentLoaded event time: " . $dom_content_loaded_time . " ms\n";
echo "Time to fully loaded: " . $time_to_fully_loaded . " ms\n";
echo "Time to visually complete: " . $time_to_visually_complete . " ms\n";
echo "Time to interactive complete: " . $time_to_interactive_complete . " ms\n";
echo "Time to first CPU idle: " . $time_to_first_cpu_idle . " ms\n";
echo "Time to first interactive: " . $time_to_first_interactive . " ms\n";
echo "Page load distribution: " . $page_load_distribution . "\n";
echo "Average page load time: " . $avg_page_load_time . " ms\n";
echo "Average server connection time: " . $avg_server_connection_time . " ms\n";
echo "Average server response time: " . $avg_server_response_time . " ms\n";
$anykey=readline("\nanykey press continue: ");

}

else if ($choice=="12") 
{
 $domain =readline("Put URL: ");
$result = shell_exec("whois $domain");

if(strpos($result, "No match for") !== false || strpos($result, "NOT FOUND") !== false) {
    echo "Domain not found.";
} else {
    // Get owner and admin contact information
    $owner = "N/A";
    $adminContact = "N/A";
    $lines = explode("\n", $result);
    foreach($lines as $line) {
        if(preg_match("/Registrant Name:(.*)/i", $line, $match)) {
            $owner = trim($match[1]);
        }
        if(preg_match("/Admin Name:(.*)/i", $line, $match)) {
            $adminContact = trim($match[1]);
        }
    }

    // Get additional information about the web server owner
    $serverIP = gethostbyname($domain);
    $serverPort = isset($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT'] : '';
    $processor = php_uname('p');
    $operatingSystem = php_uname('s') . ' ' . php_uname('r') . ' ' . php_uname('v');
    $memoryUsage = round(memory_get_usage(true) / 1024 / 1024, 2);
    $memoryLimit = ini_get('memory_limit');
    $diskTotalSpace = round(disk_total_space('/') / 1024 / 1024 / 1024, 2);
    $diskFreeSpace = round(disk_free_space('/') / 1024 / 1024 / 1024, 2);
    $uptime = shell_exec('uptime -p');
    $phpVersion = phpversion();
    $mysqlVersion = function_exists('mysqli_get_client_info') ? mysqli_get_client_info() : 'N/A';
    $apacheVersion = function_exists('apache_get_version') ? apache_get_version() : 'N/A';
    $serverSoftware = $_SERVER['SERVER_SOFTWARE'] ?? 'N/A';

    echo "Domain: $domain\n";
    echo "Owner: $owner\n";
    echo "Admin Contact: $adminContact\n";
    echo "Server IP: $serverIP\n";
    echo "Server URL: https://{$domain}:{$serverPort}\n";
    echo "Processor: {$processor}\n";
    echo "Operating System: {$operatingSystem}\n";
    echo "Memory Usage: {$memoryUsage} MB / Memory Limit: {$memoryLimit}\n";
    echo "Total Disk Space: {$diskTotalSpace} GB\n";
    echo "Free Disk Space: {$diskFreeSpace} GB\n";
    echo "Uptime: {$uptime}\n";
    echo "PHP Version: {$phpVersion}\n";
    echo "MySQL Version: {$mysqlVersion}\n";
    echo "Apache Version: {$apacheVersion}\n";
    echo "Server Software: {$serverSoftware}\n";
}
$anykey=readline("\nanykey press continue: ");

}

else if ($choice=="13") 

{
	// replace example.com with the domain name of the web server
$Input=readline("Put URL: ");
$ip_address = gethostbyname($Input);


$hostname = gethostbyaddr($ip_address);

// create the API URL with the IP address
$url = "https://freegeoip.app/json/$ip_address";

// extract the hostname from the URL

// set the options for the cURL request
$options = array(
  CURLOPT_RETURNTRANSFER => true,   // return the response as a string
  CURLOPT_FOLLOWLOCATION => true,   // follow redirects
  CURLOPT_CONNECTTIMEOUT => 10,    // timeout in seconds for the connection phase
  CURLOPT_TIMEOUT => 10,           // timeout in seconds for the entire request
);

// initialize a new cURL session
$ch = curl_init($url);

// set the options for the cURL session
curl_setopt_array($ch, $options);

// execute the cURL request and get the response
$response = curl_exec($ch);

// close the cURL session
curl_close($ch);

// parse the JSON response into an array
$geolocation = json_decode($response, true);

// check if the IP address was successfully geolocated
if (isset($geolocation['ip'])) {
  // print the geolocation data

  echo "Web Server Geolocation Data:\n";
  echo "Domain: $hostname\n";
  echo "IP Address: " . $geolocation['ip'] . "\n";
  echo "IP Version: " . (strpos($geolocation['ip'], ':') === false ? 'IPv4' : 'IPv6') . "\n";
  echo "Country: " . $geolocation['country_name'] . "\n";
  echo "Region: " . $geolocation['region_name'] . "\n";
  echo "Region Code: " . $geolocation['region_code'] . "\n";
  echo "City: " . $geolocation['city'] . "\n";
  echo "Latitude: " . $geolocation['latitude'] . "\n";
  echo "Longitude: " . $geolocation['longitude'] . "\n";
  echo "Timezone: " . $geolocation['time_zone'] . "\n";
  echo "Currency: " . (isset($geolocation['currency']) ? $geolocation['currency'] : "Not available") . "\n";
  echo "Continent: " . (isset($geolocation['continent_name']) ? $geolocation['continent_name'] : "Not available") . "\n";
  echo "Continent Code: " . (isset($geolocation['continent_code']) ? $geolocation['continent_code'] : "Not available") . "\n";
  echo "ISP: " . (isset($geolocation['org']) ? $geolocation['org'] : "Not available") . "\n";
  echo "ASN: " . (isset($geolocation['asn']) ? $geolocation['asn'] : "Not available") . "\n";
  echo "Calling Code: " . (isset($geolocation['calling_code']) ? $geolocation['calling_code'] : "Not available") . "\n";
}

 else {
  // print an error message if the IP address was not geolocated
  echo "Unable to geolocate the IP address.\n";
}
$anykey=readline("\nanykey press continue: ");

}

else if ($choice=="14") 
{
	
$url=readline("Put URL: ");
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$output = curl_exec($ch);
$info = curl_getinfo($ch);
curl_close($ch);

$requestHeaders = [];
$responseHeaders = [];
$requestUrl = '';
$responseHeaderArray = [];

// Get request URL
if (isset($info['request_header'])) {
    $requestHeaders = explode("\r\n", $info['request_header']);
    $requestLine = explode(" ", $requestHeaders[0]);
    $requestUrl = $requestLine[1];
}

// Get response headers
if (isset($info['header_size'])) {
    $responseHeaderSize = $info['header_size'];
    $responseHeaders = substr($output, 0, $responseHeaderSize);
    $responseHeaderArray = explode("\r\n", $responseHeaders);
    array_shift($responseHeaderArray);
}

echo "HTTP Request URL: " . $requestUrl . "\n";
echo "HTTP Response Headers:\n";
print_r($responseHeaderArray);
echo "\nHTTP Request Headers:\n";
print_r($requestHeaders);
echo "\n>>>>>>>>>>request method<<<<<<<<<<\n";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

// Set SSL options
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); // Set to 2 instead of 1

// Try GET request
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$response = curl_exec($ch);

if ($response !== false) {
    echo "Website supports HTTPS\n";
    
    // Try POST request
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    $response = curl_exec($ch);
    if ($response !== false) {
        echo "Supported HTTP request method: POST\n";
    }
    
    // Try PUT request
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
    $response = curl_exec($ch);
    if ($response !== false) {
        echo "Supported HTTP request method: PUT\n";
    }
    
    // Try DELETE request
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    $response = curl_exec($ch);
    if ($response !== false) {
        echo "Supported HTTP request method: DELETE\n";
    }
    
} else {
    echo "Website does not support HTTPS\n";
}

// Close curl handle
curl_close($ch);

echo "\n>>>>>>>>>>HTTP request URL<<<<<<<<<<\n";


$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Content-type: application/json'
    )
);

$context = stream_context_create($options);

$response = file_get_contents($url, false, $context);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    $regex = '/https?:\/\/[^"]+/i';
    if (preg_match($regex, $response, $matches)) {
        echo "HTTP request URL: " . $matches[0];
    } else {
        echo "Failed to extract HTTP request URL from response.\n";
        echo "Response body:\n$response\n";
    }
}

echo "\n>>>>>>>>>>content type<<<<<<<<<<\n";


$options = [
    'http' => [
        'method' => 'GET',
        'header' => 'Content-type: application/json'
    ]
];
$context = stream_context_create($options);
$response = file_get_contents($url, false, $context);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    $headers = implode("\n", $http_response_header);
    $content_type = getHeaderValue($headers, 'Content-Type');
    if ($content_type) {
        echo "HTTP response content type: " . $content_type;
    } else {
        echo "Content-Type header not found in HTTP response.";
    }
}

function getHeaderValue($headers, $headerName) {
    foreach (explode("\n", $headers) as $header) {
        $nameValue = explode(':', $header, 2);
        if (count($nameValue) == 2 && strtolower(trim($nameValue[0])) === strtolower(trim($headerName))) {
            return trim($nameValue[1]);
        }
    }
    return null;
}

echo "\n>>>>>>>>>>content length<<<<<<<<<<\n";
$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Content-type: application/json'
    )
);

$context = stream_context_create($options);

$response = file_get_contents($url, false, $context);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    $content_length = strlen($response);
    echo "HTTP response content length: " . $content_length . " bytes\n";
}

echo "\n>>>>>>>>>>content encoding<<<<<<<<<<\n";


$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Content-type: application/json'
    )
);

$context = stream_context_create($options);

$response = file_get_contents($url, false, $context);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    $headers = $http_response_header;
    foreach ($headers as $header) {
        if (strpos($header, 'Content-Encoding') !== false) {
            $content_encoding = substr($header, strlen('Content-Encoding: '));
            echo "HTTP response content encoding: " . $content_encoding . "\n";
            break;
        }
    }
}


echo "\n>>>>>>>>>>cache control<<<<<<<<<<\n";

$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Content-type: application/json'
    )
);

$context = stream_context_create($options);

$response = file_get_contents($url, false, $context);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    $headers = $http_response_header;
    foreach ($headers as $header) {
        if (strpos($header, 'Cache-Control') !== false) {
            $cache_control = substr($header, strlen('Cache-Control: '));
            echo "HTTP response cache control: " . $cache_control . "\n";
            break;
        }
    }
    if (!isset($cache_control)) {
        echo "HTTP response does not include a cache control header.\n";
    }
}

echo "\n>>>>>>>>>>cookies<<<<<<<<<<\n";


$options = array(
    'http' => array(
        'method' => 'GET',
        'header' => 'Content-type: text/html; charset=utf-8\r\n'
    )
);

$context = stream_context_create($options);
$response = file_get_contents($url, false, $context);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    $cookies = array();
    foreach ($http_response_header as $header) {
        if (strpos($header, 'Set-Cookie') !== false) {
            $cookie = substr($header, strlen('Set-Cookie: '));
            $cookie = explode(';', $cookie);
            $cookies[] = $cookie[0];
        }
    }
    echo "HTTP response cookies: \n";
    print_r($cookies);
}

echo "\n>>>>>>>>>>headers size<<<<<<<<<<\n";

$curl = curl_init($url);

curl_setopt_array($curl, array(
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HEADER => true,
));

$response = curl_exec($curl);
$header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
curl_close($curl);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    echo "HTTP response headers size: " . $header_size . " bytes\n";
}


echo "\n>>>>>>>>>>responce time<<<<<<<<<<\n";

// Create a new cURL handle
$ch = curl_init($url);

// Set the cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_NOBODY, true);

// Execute the cURL request
$start_time = microtime(true);
$response = curl_exec($ch);
$end_time = microtime(true);

// Calculate the response time
$response_time = round(($end_time - $start_time) * 1000, 2);

// Check if the request was successful and print the response time
if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    echo "HTTP response time: " . $response_time . " ms\n";
}

// Close the cURL handle
curl_close($ch);

echo "\n>>>>>>>>>>request time<<<<<<<<<<\n";

$start_time = microtime(true);

$response = file_get_contents($url);

$end_time = microtime(true);

if ($response === false) {
    echo "An error occurred while sending the request.\n";
} else {
    $request_time = round(($end_time - $start_time) * 1000, 2);
    echo "HTTP request time: {$request_time} ms\n";
}

echo "\n>>>>>>>>>>request size <<<<<<<<<<\n";

$data = 'param1=value1&param2=value2';

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute the cURL request
$response = curl_exec($ch);

// Get the request size in bytes
$request_size = curl_getinfo($ch, CURLINFO_REQUEST_SIZE);

// Close the cURL resource handle
curl_close($ch);

// Output the request size
echo 'HTTP request size: ' . $request_size . ' bytes';

echo "\n>>>>>>>>>>HTTP referer<<<<<<<<<<\n";

$options = [
    "http" => [
        "method" => "GET",
        "header" => "Content-Type: text/html; charset=UTF-8\r\n" .
                    "Referer: https://google.com\r\n"
    ]
];
$context = stream_context_create($options);
$response = file_get_contents($url, false, $context);
$referer = isset($http_response_header[2]) ? $http_response_header[2] : "";
echo "HTTP referer: " . $referer;
$anykey=readline("\nanykey press continue: ");

}
else if ($choice=="15")
{
	
// The URL to check
$url = readline("Put URL: ");

// Initialize an associative array to store the counts for each programming language
$lang_counts = array(
    "PHP" => array("count" => 0, "version" => ""),
    "ASP.NET" => array("count" => 0, "version" => ""),
    "Ruby" => array("count" => 0, "version" => ""),
    "Java" => array("count" => 0, "version" => ""),
    "Scala" => array("count" => 0, "version" => ""),
    "JavaScript" => array("count" => 0, "version" => ""),
    "static files" => array("count" => 0, "version" => ""),
    "Python" => array("count" => 0, "version" => ""),
    "ColdFusion" => array("count" => 0, "version" => ""),
    "Perl" => array("count" => 0, "version" => ""),
    "Erlang" => array("count" => 0, "version" => ""),
    "C" => array("count" => 0, "version" => ""),
    "C++" => array("count" => 0, "version" => ""),
    "C#" => array("count" => 0, "version" => ""),
    "ShellScrpt" => array("count" => 0, "version" => ""),
    ".Net" => array("count" => 0, "version" => ""),
    "Dart" => array("count" => 0, "version" => ""),
    "Go" => array("count" => 0, "version" => ""),
    "SQL" => array("count" => 0, "version" => ""),
    "Kotlin" => array("count" => 0, "version" => ""),
    "Swift" => array("count" => 0, "version" => ""),
    "HTML" => array("count" => 0, "version" => ""),
    "CSS" => array("count" => 0, "version" => ""),
    "HTML" => array("count" => 0, "version" => ""),
    "HTML" => array("count" => 0, "version" => "")
);

// Get the contents of the URL
$contents = file_get_contents("https://".($url));
echo "\n";
// Count the number of matches for each programming language
foreach ($lang_counts as $lang => &$count_arr) {
    $pattern = "/\b$lang\b/i"; // Use case-insensitive matching
    preg_match_all($pattern, $contents, $matches);
    $count_arr["count"] += count($matches[0]);

    // Version matching
    $version_pattern = "/$lang\/(\d+(\.\d+)*)/i"; // Match pattern like "PHP/7.4.23"
    preg_match($version_pattern, $contents, $version_matches);
    if (!empty($version_matches)) {
        $count_arr["version"] = $version_matches[1];
    }
}

// Calculate the total count across all programming languages
$total_count = array_sum(array_column($lang_counts, "count"));

// Initialize the table
$table = "| Languages | Percentage | Version   |\n";
$table .= "+-----------+------------+-----------+\n";

// Avoid division by zero error
if ($total_count == 0) {
    $table .= "| No programming languages detected. | | |\n";
} else {
    // Print the percentage and version for each programming language
    foreach ($lang_counts as $lang => $count_arr) {
        $count = $count_arr["count"];
        $version = $count_arr["version"];
        $percentage = ($count / $total_count) * 100;
        $table .= sprintf("| %-10s | %10s%% | %-9s |\n", $lang, number_format($percentage, 1), $version);
    }
}

// Output the table
echo $table;
$anykey=readline("\nanykey press continue: ");

}

else if ($choice=="16")
{
 
    function checkUrl($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $output = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return array("status" => $httpCode, "size" => strlen($output));
}

$path = "wordlist.txt";
$urls = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$mainUrl =readline("Put URL: ");

foreach ($urls as $url) {
    $fullUrl = "https://".$mainUrl . $url;
    $result = checkUrl($fullUrl);
    $size = $result['size'] > 0 ? round($result['size'] / 1024, 2) . " KB" : "unknown";
    $dateTime = date('Y-m-d H:i:s');

    if ($result['status'] == 200) {
        echo "Directory/File [" . $dateTime . "] [status: " . $result['status'] . "] found: " . $fullUrl . " (Size: " . $size . ")" . PHP_EOL;
    } else {
        echo "Directory/File [" . $dateTime . "] [status: " . $result['status'] . "] not found: " . $fullUrl ." (Size: 0 kB)". PHP_EOL;
    }
}
$anykey=readline("\nanykey press continue: ");

}

else if ($choice=="17")
{

$hostname = readline("Put URL: "); // Replace this with the actual hostname you want to check

// Retrieve the SSL certificate information for the given hostname
$context = stream_context_create(array("ssl" => array("capture_peer_cert" => true)));
$stream = stream_socket_client("ssl://".$hostname.":443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
$cert_info = stream_context_get_params($stream);
$cert = openssl_x509_parse($cert_info['options']['ssl']['peer_certificate']);
fclose($stream);

// Extract the SSL certificate information
$issuer = implode(", ", $cert['issuer']);
$subject = implode(", ", $cert['subject']);
$validFrom = date('Y-m-d H:i:s', $cert['validFrom_time_t']);
$validTo = date('Y-m-d H:i:s', $cert['validTo_time_t']);
$serialNumber = $cert['serialNumber'];
$signatureTypeSN = $cert['signatureTypeSN'];
$signatureTypeLN = $cert['signatureTypeLN'];
$extensions = $cert['extensions'];

// Output the SSL certificate information
echo "Hostname: ".$hostname."\n";
echo "Issuer: ".$issuer."\n";
echo "Subject: ".$subject."\n";
echo "Serial Number: ".$serialNumber."\n";
echo "Signature Algorithm: ".$signatureTypeLN." (".$signatureTypeSN.")\n";
echo "Valid From: ".$validFrom."\n";
echo "Valid To: ".$validTo."\n";
echo "Extensions: \n";
foreach ($extensions as $name => $value) {
    echo $name.": ".$value."\n";
}

// Check if the certificate is expired or not
$now = time();
if ($now < $cert['validFrom_time_t']) {
    echo "The certificate is not yet valid.\n";
} elseif ($now > $cert['validTo_time_t']) {
    echo "The certificate has expired.\n";
} else {
    echo "The certificate is valid.\n";
}

// Check if the certificate is self-signed or not
if ($issuer === $subject) {
    echo "The certificate is self-signed.\n";
} else {
    echo "The certificate is not self-signed.\n";
}

// Check if the certificate is trusted or not

$trusted = false;
$certs = [];
$context = stream_context_create(array(
    "ssl" => array(
        "verify_peer" => true,
        "allow_self_signed" => false,
        "peer_name" => $hostname
    )
));
$stream = stream_socket_client("ssl://".$hostname.":443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
if ($stream) {
    $params = stream_context_get_params($stream);
    if (isset($params["options"]["ssl"]["peer_certificate_chain"])) {
        $certs = $params["options"]["ssl"]["peer_certificate_chain"];
    }
}
foreach ($certs as $cert) {
    $cert_info = openssl_x509_parse($cert);
    if ($cert_info['issuer'] === $cert_info['subject']) {
        // We have found a self-signed certificate, so we stop here
        break;
    }
    $hash = openssl_x509_fingerprint($cert, "sha256", true);
    $hash = bin2hex($hash);
    $url = "https://crt.sh/?q=".urlencode($hash)."&output=json";
    $json = @file_get_contents($url);
    if ($json) {
        $data = json_decode($json, true);
        foreach ($data as $cert_data) {
            if ($cert_data["name_value"] === $hostname) {
                $trusted = true;
                break;
            }
        }
    }
}
if ($trusted) {
    echo "The certificate is trusted.\n";
} else {
    echo "The certificate is not trusted.\n";
}

echo "\nmore info\n";
// create stream context to capture the SSL/TLS certificate
$context = stream_context_create(['ssl' => ['capture_peer_cert' => true]]);

// connect to the website using SSL/TLS
$stream = stream_socket_client("ssl://{$hostname}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);

// get the SSL/TLS certificate from the stream context
$cert = stream_context_get_params($stream)['options']['ssl']['peer_certificate'];

// parse the SSL/TLS certificate using OpenSSL library
$certinfo = openssl_x509_parse($cert);

// display various pieces of information from the SSL/TLS certificate
echo "Subject:\t\t" . $certinfo['name'] . "\n";
echo "Issuer:\t\t" . $certinfo['issuer']['CN'] . "\n";
echo "Serial number:\t\t" . $certinfo['serialNumber'] . "\n";
echo "Valid from:\t\t" . date('D, d M Y H:i:s O', $certinfo['validFrom_time_t']) . "\n";
echo "Valid to:\t\t" . date('D, d M Y H:i:s O', $certinfo['validTo_time_t']) . "\n";
echo "Signature algorithm:\t" . $certinfo['signatureTypeSN'] . "\n";
echo "Public key algorithm:\t" . (isset($certinfo['pubkey']['type']) ? $certinfo['pubkey']['type'] : "Unknown") . "\n";
echo "Public key size:\t" . (isset($certinfo['pubkey']['bits']) ? $certinfo['pubkey']['bits'] . " bits" : "Unknown") . "\n";
echo "CA certificate:\t\t" . ($certinfo['extensions']['basicConstraints']['CA'] ?? "No") . "\n";
echo "OCSP responder:\t\t" . (is_array($certinfo['extensions']['authorityInfoAccess']['OCSP'][0] ?? null) ? implode(", ", $certinfo['extensions']['authorityInfoAccess']['OCSP'][0]) : "") . "\n";
echo "CRL endpoint:\t\t" . (is_array($certinfo['extensions']['crlDistributionPoints'] ?? null) ? implode(", ", $certinfo['extensions']['crlDistributionPoints']) : "") . "\n";
echo "DNS CAA:\t\t" . ((isset($certinfo['extensions']['subjectAltName']['dnsNames']) && is_array($certinfo['extensions']['subjectAltName']['dnsNames']) && count($certinfo['extensions']['subjectAltName']['dnsNames']) > 0 && $certinfo['extensions']['subjectAltName']['dnsNames'][0] == "CAA record for www.google.com") ? "Yes" : "No") . "\n";
echo "Extended key usage:\t" . (is_array($certinfo['extensions']['extendedKeyUsage'] ?? null) ? implode(", ", array_map(function($usage) { return $usage['oid']; }, $certinfo['extensions']['extendedKeyUsage'])) : "") . "\n";
echo "Subject Alternative Names:\t" . (is_array($certinfo['extensions']['subjectAltName']['dnsNames'] ?? null) ? implode(", ", $certinfo['extensions']['subjectAltName']['dnsNames']) : "None") . "\n";

$anykey=readline("\nanykey press continue: ");
	
}

else if ($choice=="18")
{
	$domain =readline("Put URL: ");
$records = dns_get_record($domain, DNS_ANY);
$found = false;

foreach ($records as $record) {
    if ($record["type"] == "SOA") {
        echo "Zone configuration:\n";
        echo "Primary name server: " . $record["mname"] . "\n";
        echo "Responsible party: " . $record["rname"] . "\n";
        echo "Serial number: " . $record["serial"] . "\n";
        echo "Refresh interval: " . $record["refresh"] . "\n";
        echo "Retry interval: " . $record["retry"] . "\n";
        echo "Expire time: " . $record["expire"] . "\n";
        echo "Minimum TTL: " . $record["minimum-ttl"] . "\n\n";
        $found = true;
    } elseif ($record["type"] == "TXT") {
        if (preg_match('/^v=spf1 .+? (?:v=)?\(?([\w.-]+)\)?/', $record["txt"], $matches)) {
            echo "DNS server software and version: " . $matches[1] . "\n";
            echo "Record type: " . $record["type"] . "\n";
            echo "Record class: " . $record["class"] . "\n";
            echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
            echo "Data: " . $record["txt"] . "\n\n";
            $found = true;
        }
    } else {
        echo "Record type: " . $record["type"] . "\n";
        echo "Record class: " . $record["class"] . "\n";
        echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
        if ($record["type"] == "A" || $record["type"] == "AAAA") {
            if (isset($record["ip"])) {
                echo "Data: " . $record["ip"] . "\n\n";
            } else {
                echo "Data: " . $record["ipv6"] . "\n\n";
            }
        } elseif ($record["type"] == "MX") {
            echo "Data: " . $record["pri"] . " " . $record["target"] . "\n\n";
        } elseif ($record["type"] == "NS") {
            echo "Data: " . $record["target"] . "\n\n";
        } elseif ($record["type"] == "SPF" || $record["type"] == "DKIM") {
            echo "Data: " . $record["txt"] . "\n\n";
        } elseif ($record["type"] == "DMARC") {
            echo "Record type: " . $record["type"] . "\n";
            echo "Record class: " . $record["class"] . "\n";
            echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
            echo "Data: v=" . $record["v"] . "; p=" . $record["p"] . "; sp=" . $record["sp"] . "; rua=" . $record["rua"] . "; ruf=" . $record["ruf"] . "\n\n";
} elseif ($record["type"] == "A" || $record["type"] == "AAAA") {
echo "Record type: " . $record["type"] . "\n";
echo "Record class: " . $record["class"] . "\n";
echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
if (isset($record["ip"])) {
echo "Data: " . $record["ip"] . "\n\n";
} else {
echo "Data: " . $record["ipv6"] . "\n\n";
}
} elseif ($record["type"] == "MX") {
echo "Record type: " . $record["type"] . "\n";
echo "Record class: " . $record["class"] . "\n";
echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
echo "Data: " . $record["pri"] . " " . $record["target"] . "\n\n";
} elseif ($record["type"] == "NS") {
echo "Record type: " . $record["type"] . "\n";
echo "Record class: " . $record["class"] . "\n";
echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
echo "Data: " . $record["target"] . "\n\n";
} elseif ($record["type"] == "SPF" || $record["type"] == "DKIM") {
echo "Record type: " . $record["type"] . "\n";
echo "Record class: " . $record["class"] . "\n";
echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
echo "Data: " . $record["txt"] . "\n\n";
} else {
echo "Record type: " . $record["type"] . "\n";
echo "Record class: " . $record["class"] . "\n";
echo "Time-to-live: " . gmdate("H:i:s", $record["ttl"]) . "\n";
echo "Data: " . $record["target"] . "\n\n";
}
$found = true;
}
}

if (!$found) {
echo "No SOA or TXT records found for domain: " . $domain;
}
echo "\n More information:\n";
function get_dns_info($domain) {
    $ip = gethostbyname($domain);
    $tld = strtolower(pathinfo($domain, PATHINFO_EXTENSION));
    
    if ($tld === 'edu') {
        $dns_servers = ['8.8.8.8', '8.8.4.4']; // Google DNS servers for .edu domains
    } elseif ($tld === 'gov') {
        $dns_servers = ['149.101.1.1', '149.101.2.2']; // US government DNS servers for .gov domains
    } else {
        $dns_servers = ['8.8.8.8', '8.8.4.4']; // Default Google DNS servers
    }
    
    $dns_info = [];
    
    foreach ($dns_servers as $server) {
        $output = shell_exec("nslookup -type=A -timeout=5 -retry=1 $domain $server");
        if (strpos($output, 'name =') !== false) {
            $dns_servers_str = $server;
            $dns_version = 'N/A';
            $output_arr = explode("\n", $output);
            foreach ($output_arr as $line) {
                if (strpos($line, 'version = ') !== false) {
                    $dns_version = trim(str_replace('version = ', '', $line));
                }
            }
            $version_output = shell_exec("dig @{$server} version.bind chaos txt");
            if (strpos($version_output, "VERSION.BIND.\\001") !== false) {
                $version_str = str_replace(["\n", "\t", "\""], '', $version_output);
                $version_arr = explode(" ", $version_str);
                $dns_version = end($version_arr);
            }
            $dns_info[] = [
                'dns_server' => $dns_servers_str,
                'dns_version' => $dns_version
            ];
        }
    }
    
    return [
        'domain' => $domain,
        'ip_address' => $ip,
        'dns_info' => $dns_info,
        'php_version' => phpversion(),
    ];
}

// Example usage
// $domain = 'www.google.com';
$info = get_dns_info($domain);
echo "Domain: " . $info['domain'] . "\n";
echo "IP address: " . $info['ip_address'] . "\n";
foreach ($info['dns_info'] as $dns) {
    echo "DNS server: " . $dns['dns_server'] . "\n";
    if ($dns['dns_version'] === 'N/A') {
        echo "DNS version: Not available\n";
    } else {
        echo "DNS version: " . $dns['dns_version'] . "\n";
    }
}
echo "PHP version: " . $info['php_version'] . "\n";
$anykey=readline("\nanykey press continue: ");

}


else if ($choice=="19") 
{
$hostname = readline("Put URL: ");
$context = stream_context_create(['ssl' => ['capture_peer_cert' => true]]);
$stream = stream_socket_client("ssl://{$hostname}:443", $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $context);
$cert = stream_context_get_params($stream)['options']['ssl']['peer_certificate'];

$certinfo = openssl_x509_parse($cert);
$fingerprint_sha256 = openssl_x509_fingerprint($cert, 'sha256');
$fingerprint_sha1 = openssl_x509_fingerprint($cert, 'sha1');
$certinfo = openssl_x509_parse($cert, false);

echo "Fingerprint (SHA256):\t" . chunk_split($fingerprint_sha256, 2, ':') . "\n";
echo "Fingerprint (SHA1):\t" . chunk_split($fingerprint_sha1, 2, ':') . "\n";
echo "Fingerprint algorithm:\t" . $certinfo['signatureTypeLN'] . "\n";

$der_cert = '';
openssl_x509_export($cert, $der_cert);
$hash_algorithm = 'sha256'; // can be changed to other hash algorithms
$fingerprint_hash = openssl_digest($der_cert, $hash_algorithm, true);
$fingerprint_hash_hex = bin2hex($fingerprint_hash);
echo "Fingerprint hash:\t" . chunk_split($fingerprint_hash_hex, 2, ':') . "\n";

echo "Fingerprint hash algorithm:\t" . strtoupper($hash_algorithm) . "\n";

$anykey=readline("\nanykey press continue: ");

}


else if ($choice=="20")
{
	$domain = readline("Put URL: ");
$whois = shell_exec("whois $domain");

$info = explode("\n", $whois);

$domain_name = "";
$registrar = "";
$nameserver = "";
$organisation = "";
$admin_email = "";
$dnssec = "";
$firewall = "";

foreach ($info as $line) {
  if (strpos($line, "Domain Name:") !== false) {
    $domain_name = trim(str_replace("Domain Name:", "", $line));
  }
  if (strpos($line, "Registrar:") !== false) {
    $registrar = trim(str_replace("Registrar:", "", $line));
  }
  if (strpos($line, "Name Server:") !== false) {
    $nameserver = trim(str_replace("Name Server:", "", $line));
  }
  if (strpos($line, "Registrant Organization:") !== false) {
    $organisation = trim(str_replace("Registrant Organization:", "", $line));
  }
  if (strpos($line, "Registrant Email:") !== false) {
    $admin_email = trim(str_replace("Registrant Email:", "", $line));
  }
  if (strpos($line, "DNSSEC:") !== false) {
    $dnssec = trim(str_replace("DNSSEC:", "", $line));
  }
  if (strpos($line, "firewall:") !== false) {
    $firewall = trim(str_replace("firewall:", "", $line));
  }
}

$top_level_domain = "";
$domain_parts = explode(".", $domain_name);
if (count($domain_parts) > 1) {
    $top_level_domain = end($domain_parts);
}

if ($top_level_domain != "") {
  echo "Top Level Domain: " . $top_level_domain . "\n";
} else {
  echo "Top Level Domain: Not Present\n";
}

echo "Domain: " . $domain_name . "\n";
echo "Nameserver: " . $nameserver . "\n";
echo "Domain registrar: " . $registrar . "\n";
echo "Nameserver organisation: " . $organisation . "\n";
echo "Organisation: " . $organisation . "\n";
echo "DNS admin: " . $admin_email . "\n";
echo "DNS Security Extensions: " . $dnssec . "\n";

$firewall_manufacturers = array(
    'Cisco',
    'aeSecure',
    'Airee',
    'Phion/Ergon',
    'Alert Logic',
    'Alibaba Cloud Computing',
    'Anquanbao',
    'AnYu Technologies',
    'Approach',
    'Radware',
    'Armor',
    'ArvanCloud',
    'Microsoft',
    'ASPA Engineering Co.',
    'Czar Securities',
    'Amazon',
    'AzionCDN',
    'Ethic Ninja',
    'Barracuda Networks',
    'Faydata Technologies Inc.',
    'Beluga',
    'F5 Networks',
    'BinarySec',
    'BitNinja',
    'BlockDoS',
    'Bluedon IST',
    'AITpro Security',
    'Varnish',
    'Comodo CyberSecurity',
    'CdnNs/WdidcNet',
    'Yunaq',
    'Penta Security',
    'Cloudflare Inc.',
    'Cloudfloor DNS',
    'Amazon',
    'Jean-Denis Brun',
    'IBM',
    'Rohde & Schwarz'
);

if ($firewall !== "") {
  $found = false;
  foreach ($firewall_manufacturers as $manufacturer) {
    if (stripos($firewall, $manufacturer) !== false) {
      echo "Manufacturer: " . $manufacturer . "\n";
      $found = true;
      break;
    }
  }
  if (!$found) {
    echo "Manufacturer: Not Found\n";
  }
} else {
  echo "Firewall: Unknown\n";
}

$edu_tlds = array( 'us' => 'edu', 'uk' => 'ac.uk', 'au' => 'edu.au', 'ca' => 'edu', 'in' => 'ac.in', 'jp' => 'ac.jp', 'fr' => 'edu.fr', 'de' => 'edu', 'cn' => 'edu.cn', 'kr' => 'ac.kr', 'mx' => 'edu.mx', 'it' => 'edu.it', 'ru' => 'edu.ru', 'br' => 'edu.br', 'com' => 'edu', 'manufacturer' => 'manuf' );
if (isset($edu_tlds[$top_level_domain]) && $top_level_domain == $edu_tlds[$top_level_domain]) {
  echo "This is an educational domain.\n";
} 
$anykey=readline("\nanykey press continue: ") ;  
}

else if ($choice=="21")
{
  
   echo "how to useage tool?.\n1)select target through number \n2)just type then target url like [www.example.com]\n3)press Enter";

	$anykey=readline("\nanykey press continue: ");
}

else if ($choice=="22")
{
 echo "This tool created in Php language. really very helpful for info getharing.\nIts me Hamza Fawad tool Owner\n3 Years experience in CyberSecurity Field\n";	
  echo "About Tool:\nWeb_Server_Spy V:1.0 => can do this\n";

echo "1 Hostname/IP address\n";
echo "2 Operating system\n";
echo "3 Web server software (e.g. Apache, Nginx, IIS)\n";
echo "4 Server-side programming languages (e.g. PHP, Python, Ruby)\n";
echo "5 Server-side scripting language version (e.g. PHP 7.4, Python 3.9)\n";
echo "6 Database software (e.g. MySQL, PostgreSQL, MongoDB)\n";
echo "7 Database version (e.g. MySQL 8.0.27, PostgreSQL 14.1)\n";
echo "8 Content management system (CMS) (e.g. WordPress, Drupal, Joomla)\n";
echo "9 CMS version (e.g. WordPress 5.8.1, Drupal 9.3.0)\n";
echo "10 Firewall software (e.g. iptables, ufw, Windows Firewall)\n";
echo "11 SSL certificate provider (e.g. Let's Encrypt, DigiCert, Comodo)\n";
echo "12 SSL certificate status (e.g. valid, expired, self-signed)\n";
echo "13Email server software (e.g. Postfix, Sendmail, Exim)\n";
echo "14 Email server version (e.g. Postfix 3.6.14, Sendmail 8.16.1)\n";
echo "15 Backup software (e.g. rsync, Bacula, Duplicati)\n";
echo "16 Backup frequency (e.g. daily, weekly, monthly)\n";
echo "17 Load balancer software (e.g. HAProxy, Nginx, Amazon ELB)\n";
echo "18 Cache software (e.g. Varnish, Memcached, Redis)\n";
echo "19 Web analytics software (e.g. Google Analytics, Piwik/Matomo, AWStats)\n";

	$anykey=readline("\nanykey press continue: ");
}

else if($choice=="23")
{
	echo "Thank you for using...!\n";
	exit();
}

else
{
	echo "Wrong Chose Seleted\n";
}

}

?>
// end of tool